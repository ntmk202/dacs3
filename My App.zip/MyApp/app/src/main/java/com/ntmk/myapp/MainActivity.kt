package com.ntmk.myapp

import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Pair
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        Handler().postDelayed({
            val intent = Intent(this@MainActivity, LoginActivity::class.java)
            val options = ActivityOptions.makeSceneTransitionAnimation(
                this@MainActivity,
                Pair.create<View, String>(img_logo, "logo_img"),
                Pair.create<View, String>(txt_logo, "logo_txt")
            )
            startActivity(intent, options.toBundle())
        }, 2000)

//        Handler().postDelayed({
//            startActivity(Intent(this@MainActivity, LoginActivity::class.java))
//            finish()
//        }, 2000)
    }
}