package com.ntmk.myapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)



        txtLink_signup.setOnClickListener(View.OnClickListener { view: View? ->
            startActivity(
                Intent( this@LoginActivity, RegistrationActivity::class.java)
            )
        })
    }

}